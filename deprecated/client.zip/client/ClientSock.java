package client;


import util.Log;
import java.net.Socket;
import java.net.UnknownHostException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;


public class ClientSock {

	private Socket clientSocket;
	private BufferedReader IN;
	private PrintWriter OUT;


	public ClientSock() {}


	public ClientSock(Socket clientSocket) {
		this.clientSocket = clientSocket;
	}
	

	public InputStream getInputStream() {
		if (this.clientSocket != null) {
			try {
				return this.clientSocket.getInputStream();
			}
			catch (IOException e) {
				Log.stdlog("WARN", "ClientSock", "IOException thrown by getInputStream, returning null");
				Log.stdlog("WARN", "ClientSock", "\t" + e);
				return null;
			}
		}
		return null;
	}


	public OutputStream getOutputStream() {
		if (this.clientSocket != null) {
			try {
				return this.clientSocket.getOutputStream();
			}
			catch (IOException e) {
				Log.stdlog("WARN", "ClientSock", "IOException thrown by getOutputStream, returning null");
				Log.stdlog("WARN", "ClientSock", "\t" + e);
				return null;
			}
		}
		return null;
	}


	public void connect(String ip, int port) {
		try {
			if (this.clientSocket == null)
				this.clientSocket = new Socket(ip, port);
			this.IN = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));
			this.OUT = new PrintWriter(this.clientSocket.getOutputStream(), true); // true for autoFlush
		}
		catch (IOException e) {
			Log.stdlog("ERROR", "ClientSock", "IOException thrown when initializing socket");
			Log.stdlog("ERROR", "ClientSock", "\t" + e);
		}
	}


	public void send(String msg) {
		if (this.OUT != null) {
			this.OUT.println(msg);
			return;
		}
		Log.stdlog("WARN", "ClientSock", "OUT was null, no message sent");
	}


	public String recv() {
		if (this.IN != null) {
			try {
				return this.IN.readLine();
			}
			catch (IOException e) {
				Log.stdlog("ERROR", "ClientSock", "IOException thrown from IN.readLine(), returning null");
				return null;
			}
		}
		Log.stdlog("WARN", "ClientSock", "IN was null, returning null");
		return null;
	}


	public void close() {
		if (this.clientSocket != null) {
			try {
				this.clientSocket.close();
			}
			catch (IOException e) {
				Log.stdlog("ERROR", "ClientSock", "clientSocket could not be closed");
				Log.stdlog("ERROR", "ClientSock", "\t" + e);
			}
		}
	}
	
}

