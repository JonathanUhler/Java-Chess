package client;


import util.StringUtility;
import util.Coordinate;
import server.Server;
import engine.move.Move;
import engine.move.MoveGenerator;
import engine.board.BoardInfo;
import engine.fen.FenUtility;
import engine.piece.Piece;
import java.awt.event.MouseEvent;
import javax.swing.event.MouseInputAdapter;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.util.ArrayList;
import java.util.Map;


public class GUI extends JPanel {

	// Margins and sizes
	private static final int MARGIN = 40;
	private static final int TILE_SIZE = 70;

	private JLayeredPane pieces;
	private ArrayList<Coordinate> highlightedTiles;
	
	private BoardInfo boardInfo;
	private ClientSock clientSocket;
	private int color;


	public GUI() {
		this.setPreferredSize(new Dimension(GUI.MARGIN + (GUI.TILE_SIZE * 8) + GUI.MARGIN,
											GUI.MARGIN + (GUI.TILE_SIZE * 8) + GUI.MARGIN));
		
		JTextField ipTextField = new JTextField(10);
		JTextField portTextField = new JTextField(4);
		JButton hostButton = new JButton("Host Game");
		hostButton.addActionListener(e -> this.hostServer(ipTextField.getText(), portTextField.getText()));
		JButton joinButton = new JButton("Join Game");
		joinButton.addActionListener(e -> this.connectClient(ipTextField.getText(), portTextField.getText()));

		this.add(new JLabel("IP Addr:"));
		this.add(ipTextField);
		this.add(new JLabel("Port:"));
		this.add(portTextField);
		this.add(hostButton);
		this.add(joinButton);

		this.highlightedTiles = new ArrayList<>();
		this.pieces = new JLayeredPane();

		this.color = 0;
		this.updatePosition("8/8/8/8/8/8/8/8 w - - 0 1");
	}


	private void hostServer(String ip, String stringPort) {
		int port = Integer.parseInt(stringPort);
		Thread serverThread = new Thread(new Runnable() {
				@Override
				public void run() {
					Server server = new Server(ip, port);
				}
			});
		serverThread.start();

		// Small delay to make sure the server is up
		try {
			Thread.sleep(100);
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		this.connectClient(ip, stringPort);
	}


	private void connectClient(String ip, String stringPort) {
		int port = Integer.parseInt(stringPort);
		this.clientSocket = new ClientSock();
		this.clientSocket.connect(ip, port);

		// Initial handshake
		// MARK: TO DO: add in error/null/key checking here
		String recv = this.clientSocket.recv();
		Map<String, String> mapRecv = StringUtility.stringToMap(recv);
		this.color = Integer.parseInt(mapRecv.get("color"));
		this.updatePosition(mapRecv.get("fen"));

		Thread listenThread = new Thread(this::listen);
		listenThread.start();
	}


	private void listen() {
		while (true) {
			String recv = this.clientSocket.recv();
			if (recv == null)
				continue;

			// MARK: TO DO: more error/null/key checking here
			Map<String, String> mapRecv = StringUtility.stringToMap(recv);
			this.updatePosition(mapRecv.get("fen"));
			// MARK: TO DO: DO THE "state" CHECKING HERE and display end game message if needed
		}
	}

	
	private void updatePosition(String fenString) {
		this.boardInfo = FenUtility.informationFromFen(fenString);
		this.drawPosition();
	}


	private void drawPosition() {
		this.pieces.removeAll();
		this.pieces.setBounds(0, 0, this.getPreferredSize().width, this.getPreferredSize().height); // MARK: TO DO: does this need to be here? or can it be in the constructor

		if (this.boardInfo != null) {
			for (Coordinate c : Coordinate.getAllValidCoordinates()) {
				Piece piece = this.boardInfo.getPiece(c);
				if (piece != null) {
					// displayOffsetY used to reflect the board across the x-axis depending on which perspective
					// is being viewed
					int displayOffsetY = (this.color != Piece.Color.BLACK) ? (7 - c.getY()) : (c.getY());
					int x = GUI.MARGIN + (c.getX() * GUI.TILE_SIZE);
					int y = GUI.MARGIN + (displayOffsetY * GUI.TILE_SIZE);

					String pieceImageFile = piece.getType() + "" + piece.getColor() + ".png";
					// MARK: TO DO: add these images to the jar and reference them from there
					JLabel pieceImage = new JLabel(new ImageIcon("/Users/jonathan/Documents/Computer-Science/Java/Networking-Chess/src/reference/" + pieceImageFile));
					pieceImage.setBounds(x, y, GUI.TILE_SIZE, GUI.TILE_SIZE);

					if (this.color != Piece.Color.NONE) {
						pieceImage.addMouseListener(new MouseInputAdapter() {
								@Override
								public void mousePressed(MouseEvent e) {
									System.out.println("PRESSED");
									GUI.this.pieceClicked(e, pieceImage);
								}
								@Override
								public void mouseReleased(MouseEvent e) {
									System.out.println("RELEASED");
									GUI.this.pieceReleased(e, pieceImage);
								}
								// MIGHT NEED TO PUT DRAGGED METHOD IN A mouseMotionListener INSTEAD OF
								// THIS mouseListener, BUT THERE IS STILL THE ISSUE WITH RELEASED NOT
								// WORKING WHEN IT SHOULD
								@Override
								public void mouseDragged(MouseEvent e) {
									System.out.println("DRAGGED");
									GUI.this.pieceDragged(e, pieceImage);
								}
							});
					}
					
					this.pieces.add(pieceImage);
				}
			}
		}

		this.add(this.pieces); // MARK: TO DO: --------------------------------------------does this need to be here? or can it be in the constructor
		this.repaint();
	}


	private void pieceClicked(MouseEvent e, JLabel piece) {
		this.highlightedTiles = new ArrayList<>();

		int xTile = Math.round(piece.getLocation().x / GUI.TILE_SIZE);
		int yTile = Math.round(piece.getLocation().y / GUI.TILE_SIZE);
		if (this.color != Piece.Color.BLACK)
			yTile = 7 - yTile;
		Coordinate click = new Coordinate(xTile, yTile);

		ArrayList<Move> legalMoves = MoveGenerator.generateLegalMoves(this.boardInfo);
		for (Move m : legalMoves) {
			if (m.getStartTile().equals(click))
				this.highlightedTiles.add(m.getEndTile());
		}

		this.repaint();
	}


	private void pieceDragged(MouseEvent e, JLabel piece) {
		System.out.println("DRAGGED");
		this.repaint();
	}


	private void pieceReleased(MouseEvent e, JLabel piece) {
		this.highlightedTiles = new ArrayList<>();
		this.repaint();
	}

	
	@Override
	public void paintComponent(Graphics g) {
		g.drawString("Position: " + this.boardInfo.fenString, 50,
					 GUI.MARGIN + (GUI.TILE_SIZE * 8) + (int)(GUI.MARGIN / 1.5));

		for (Coordinate c : Coordinate.getAllValidCoordinates()) {
			g.setColor(new Color(0, 0, 0));
			if (this.highlightedTiles.contains(c))
				g.setColor(new Color(255, 0, 0));

			int displayOffsetY = (this.color != Piece.Color.BLACK) ? (7 - c.getY()) : (c.getY());
			g.drawRect(GUI.MARGIN + (c.getX() * GUI.TILE_SIZE),
					   GUI.MARGIN + (displayOffsetY * GUI.TILE_SIZE),
					   GUI.TILE_SIZE, GUI.TILE_SIZE);
		}

		this.drawPosition();
	}

}
